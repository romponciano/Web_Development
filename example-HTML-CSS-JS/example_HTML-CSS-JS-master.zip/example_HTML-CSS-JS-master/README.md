# Exemplo básico HTML/CSS e javascript

### en-us
A problem set (pset) of the 1st semester of college. It was to create a simple website using html/css and javascript.<br>
I will soon implement a login section (connecting to a database) using PHP.<br>

obs.: The javascript lies directly in the header of each page (it was a requirement of pset).

### pt-br
Um trabalho realizado no 1º semestre da faculdade. Foi a criação de um site simples utilizando html/css e javascript.<br>
Em breve irei implementar uma seção de login (conectando-se com um banco de dados) utilizando PHP.<br>

obs.: O javascript encontra-se diretamente no cabeçalho de cada página (era um requisito do trabalho).

